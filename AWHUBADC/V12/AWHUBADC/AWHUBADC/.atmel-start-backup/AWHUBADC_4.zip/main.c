#include <atmel_start.h>
#include <stdio.h>
#include <util/delay.h>
#include <avr/io.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		ADC0.MUXPOS = ADC_MUXPOS_GND_gc;
		_delay_us(100);
		int16_t var1 = ADC_0_get_conversion(6);
		
		
		//ADC0.MUXPOS = ADC_MUXPOS_INTREF_gc;
		//_delay_us(100);
		int16_t var2 = 0;//ADC_0_get_conversion(6);
		
		printf("data: %4d\r", (var1 - var2) );
		_delay_ms(100);
	}
}

//ATtiny817