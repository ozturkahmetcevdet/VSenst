/*
 * tiny_qtouch_adc.c
 *
 * Created: 27.07.2021 08:14:38
 *  Author: ahmet
 */ 

#include <tiny_qtouch_adc.h>

uint16_t TOUCH_GetSensorValue(uint8_t touchPin, uint8_t partner, bool dir)
{
	//uint8_t pinMask
}