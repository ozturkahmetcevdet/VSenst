#include <atmel_start.h>
#include <stdio.h>
#include <util/delay.h>
#include <avr/io.h>
#include <tiny_qtouch_adc.h>

int32_t adc1 = 0, adc2 = 0;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		for (uint8_t i = 0; i < 128; i++)
		{
			adc1 += TOUCH_GetSensorValue(0, false);
			adc2 += TOUCH_GetSensorValue(0, true);
		}
		adc1 >>= 7;
		adc2 >>= 7;
		
		//printf("adc1: %4d, adc2: %4d\r",adc1, adc2);
		printf("data: %4d\r",(uint16_t)(adc1 - adc2));
		_delay_ms(500);
	}
}

//ATtiny817