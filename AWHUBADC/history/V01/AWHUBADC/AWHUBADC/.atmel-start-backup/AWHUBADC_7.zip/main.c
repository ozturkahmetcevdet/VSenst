#include <atmel_start.h>
#include <stdio.h>
#include <util/delay.h>
#include <avr/io.h>
#include <tiny_qtouch_adc.h>

int32_t adc1 = 0, adc2 = 0;
int32_t ref1 = 0, ref2 = 0; 
int16_t ref = 0;

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();
	
	TOUCH_GetSensorValue(0, false);
	TOUCH_GetSensorValue(0, true);
	
	for (uint8_t i = 0; i < 64; i++)
	{
		ref1 += TOUCH_GetSensorValue(0, false);
		ref2 += TOUCH_GetSensorValue(0, true);
	}
	ref1 >>= 6;
	ref2 >>= 6;
	
	ref = (uint16_t)(ref1 - ref2);

	/* Replace with your application code */
	while (1) {
		for (uint8_t i = 0; i < 64; i++)
		{
			adc1 += TOUCH_GetSensorValue(0, false);
			adc2 += TOUCH_GetSensorValue(0, true);
		}
		adc1 >>= 6;
		adc2 >>= 6;
		
		//printf("adc1: %4d, adc2: %4d\r",adc1, adc2);
		printf("data: %4d\r",((uint16_t)(adc1 - adc2) - ref));
		_delay_ms(2000);
	}
}

//ATtiny817