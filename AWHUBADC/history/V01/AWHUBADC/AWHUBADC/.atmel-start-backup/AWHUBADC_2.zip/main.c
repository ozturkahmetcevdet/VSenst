#include <atmel_start.h>
#include <stdio.h>
#include <util/delay.h>

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	/* Replace with your application code */
	while (1) {
		uint16_t var = ADC_0_get_conversion(0);
		printf("data: %u\n\r", var);
		_delay_ms(100);
	}
}

//ATtiny817