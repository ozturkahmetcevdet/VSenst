﻿/*
 * tiny_qtouch_adc.h
 *
 * Created: 27.07.2021 08:15:52
 *  Author: ahmet
 */ 
#ifndef TINY_QTOUCH_ADC_H_
#define TINY_QTOUCH_ADC_H_

#include <compiler.h>
#include <tiny_qtouch_adc.h>

#ifdef __cplusplus
extern "C" {
	#endif



	#ifdef __cplusplus
}
#endif