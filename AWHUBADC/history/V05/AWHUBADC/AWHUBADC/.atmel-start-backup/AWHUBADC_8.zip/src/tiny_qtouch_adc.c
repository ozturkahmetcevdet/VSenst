/*
 * tiny_qtouch_adc.c
 *
 * Created: 27.07.2021 08:14:38
 *  Author: ahmet
 */ 

#include <tiny_qtouch_adc.h>
#include <atmel_start.h>

#include <util/delay.h>

uint16_t TOUCH_GetSensorValue(uint8_t touchPin, bool dir)
{
	SHIELD_set_level(false);
	
	switch (touchPin)
	{
		case 0:
			SHIELD_set_level(false);
			PARTNER_set_level(dir);
			PARTNER_set_dir(PORT_DIR_OUT);
			ADC0.MUXPOS = ADC_MUXPOS_AIN10_gc;
			
			SX_set_level(!dir);
			SX_set_dir(PORT_DIR_OUT);
			//SX_set_pull_mode(dir ? PORT_PULL_OFF : PORT_PULL_UP);
			_delay_us(CHARGE_DELAY);
			
			SX_set_dir(PORT_DIR_IN);
			SX_set_isc(PORT_ISC_INPUT_DISABLE_gc);
			SX_set_pull_mode(PORT_PULL_OFF);
			
			//ADC0.MUXPOS = ADC_MUXPOS_AIN6_gc;			
			//_delay_us(TRANSFER_DELAY);
			
			uint16_t var = ADC_0_get_conversion(ADC_MUXPOS_AIN6_gc);
			
			PARTNER_set_dir(PORT_DIR_IN);
			PARTNER_set_isc(PORT_ISC_INPUT_DISABLE_gc);
			PARTNER_set_pull_mode(PORT_PULL_OFF);
			SX_set_level(false);
			SX_set_dir(PORT_DIR_OUT);
			
			return var;
		break;
		
		case 1:
		break;
		
		default:
		break;
	}
	
	return 0;
}

//ATtiny817
